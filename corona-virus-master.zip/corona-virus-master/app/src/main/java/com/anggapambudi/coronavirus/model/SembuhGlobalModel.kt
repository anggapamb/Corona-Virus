package com.anggapambudi.coronavirus.model

import com.google.gson.annotations.SerializedName

data class SembuhGlobalModel(
    @SerializedName("value")
    val valueSembuhGlobal: String
)