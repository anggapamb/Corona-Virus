package com.anggapambudi.coronavirus.model

import com.google.gson.annotations.SerializedName

data class PositifGlobalModel(
    @SerializedName("value")
    val valuePositifGlobal: String
)