package com.anggapambudi.coronavirus.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.anggapambudi.coronavirus.R
import com.anggapambudi.coronavirus.model.DataProvinsiModel
import kotlinx.android.synthetic.main.item_recyclerview_provinsi_home.view.*

class ProvinsiAdapter(private val context: Context, private val list: ArrayList<DataProvinsiModel>):
        RecyclerView.Adapter<ProvinsiAdapter.ProvinsiViewHolder>() {

    class ProvinsiViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        fun bind(dataProvinsiModel: DataProvinsiModel) {
            itemView.tvNameProvinsi.text = dataProvinsiModel.attributes.provinsi
            itemView.tvPositifProvinsi.text = "Positif : ${dataProvinsiModel.attributes.positifProvinsi}"
            itemView.tvSembuhProvinsi.text = "Sembuh : ${dataProvinsiModel.attributes.sembuhProvinsi}"
            itemView.tvMeninggalProvinsi.text = "Meninggal : ${dataProvinsiModel.attributes.meninggalProvinsi}"
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)= ProvinsiViewHolder(
        LayoutInflater.from(context).inflate(R.layout.item_recyclerview_provinsi_home, parent, false)
    )

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ProvinsiViewHolder, position: Int) {
        holder.bind(list[position])
    }

}