package com.anggapambudi.coronavirus.model

data class DataIndonesiaModel(
    val name: String,
    val positif: String,
    val sembuh: String,
    val meninggal: String,
    val dirawat: String
)