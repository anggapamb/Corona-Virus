package com.anggapambudi.coronavirus.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.SearchView
import androidx.recyclerview.widget.GridLayoutManager
import com.anggapambudi.coronavirus.R
import com.anggapambudi.coronavirus.adapter.ProvinsiAdapter
import com.anggapambudi.coronavirus.api.ApiService
import com.anggapambudi.coronavirus.model.DataProvinsiModel
import kotlinx.android.synthetic.main.activity_provinsi_detail.*
import org.jetbrains.anko.find
import org.jetbrains.anko.sdk27.coroutines.onClick
import org.jetbrains.anko.toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class ProvinsiDetailActivity : AppCompatActivity() {

    private val list = ArrayList<DataProvinsiModel>()
    private val displayList = ArrayList<DataProvinsiModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_provinsi_detail)

        //set toolbar
        setSupportActionBar(toolbar)

        rvRecyclerviewProvinsiDetail.layoutManager = GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false)

        ApiService.instance.getDataProvinsi().enqueue(object : Callback<ArrayList<DataProvinsiModel>>{
            override fun onFailure(call: Call<ArrayList<DataProvinsiModel>>, t: Throwable) {
                toast("Gagal mengambil data Provinsi")
            }

            override fun onResponse(
                call: Call<ArrayList<DataProvinsiModel>>,
                response: Response<ArrayList<DataProvinsiModel>>
            ) {
                val dataProvinsiDetail = response.body()!!
                dataProvinsiDetail.let { list.addAll(it) }
                displayList.addAll(list)
                rvRecyclerviewProvinsiDetail.adapter = ProvinsiAdapter(this@ProvinsiDetailActivity, displayList)
            }

        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        
        menuInflater.inflate(R.menu.menu_provinsi_detail, menu)
        val menuItem = menu!!.findItem(R.id.idSearchView)

        if (menuItem != null){

            val searchView = menuItem.actionView as SearchView

            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                override fun onQueryTextSubmit(p0: String?): Boolean {
                    return true
                }

                override fun onQueryTextChange(p0: String?): Boolean {

                    if (p0!!.isNotEmpty()) {

                        displayList.clear()
                        val search = p0.toLowerCase(Locale.getDefault())
                        list.forEach {

                            if (it.attributes.provinsi.toLowerCase(Locale.getDefault()).contains(search)) {

                                displayList.add(it)

                            }
                        }

                        rvRecyclerviewProvinsiDetail.adapter!!.notifyDataSetChanged()
                    } else {

                        displayList.clear()
                        displayList.addAll(list)
                        rvRecyclerviewProvinsiDetail.adapter!!.notifyDataSetChanged()

                    }

                    return true
                }


            })

        }

        return super.onCreateOptionsMenu(menu)
    }

    //kasih onClick biasa pada menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return super.onOptionsItemSelected(item)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }


}