package com.anggapambudi.coronavirus.model

import com.google.gson.annotations.SerializedName

data class ProvinsiModel(
    @SerializedName("Provinsi")
    val provinsi: String,
    @SerializedName("Kasus_Posi")
    val positifProvinsi: Int,
    @SerializedName("Kasus_Semb")
    val sembuhProvinsi: Int,
    @SerializedName("Kasus_Meni")
    val meninggalProvinsi: Int
)