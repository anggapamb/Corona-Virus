package com.anggapambudi.coronavirus.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.anggapambudi.coronavirus.R
import com.anggapambudi.coronavirus.adapter.ProvinsiAdapter
import com.anggapambudi.coronavirus.api.ApiService
import com.anggapambudi.coronavirus.model.*
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.sdk27.coroutines.onClick
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private val list = ArrayList<DataProvinsiModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //getData global
        showPositifGlobal()
        showSembuhGlobal()
        showMeninggalGlobal()

        //getDataIndonesia
        showDataIndonesia()

        //getDataProvinsi
        showDataProvinsi()

        //recyclerview provinsi
        rvRecyclerviewProvinsiHome.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        //text onClick
        textSeeMore.onClick {
            startActivity<ProvinsiDetailActivity>()
        }


    }

    private fun showDataProvinsi() {
        ApiService.instance.getDataProvinsi().enqueue(object : Callback<ArrayList<DataProvinsiModel>>{
            override fun onFailure(call: Call<ArrayList<DataProvinsiModel>>, t: Throwable) {
                toast("Gagal engambil data Provinsi")
            }

            override fun onResponse(
                call: Call<ArrayList<DataProvinsiModel>>,
                response: Response<ArrayList<DataProvinsiModel>>
            ) {
                val dataProvinsi = response.body()!!
                dataProvinsi.let { list.addAll(it) }
                rvRecyclerviewProvinsiHome.adapter = ProvinsiAdapter(this@MainActivity, list)

            }

        })
    }

    private fun showDataIndonesia() {
        ApiService.instance.getDataIndonesia().enqueue(object : Callback<ArrayList<DataIndonesiaModel>>{
            override fun onFailure(call: Call<ArrayList<DataIndonesiaModel>>, t: Throwable) {
                toast("Gagal mengambil data Indonesia")
            }

            override fun onResponse(
                call: Call<ArrayList<DataIndonesiaModel>>,
                response: Response<ArrayList<DataIndonesiaModel>>
            ) {
                val responseDataIndonesia = response.body()!!
                val dataIndonesia = responseDataIndonesia[0]
                tvPositifIndonesia.text = dataIndonesia.positif
                tvSembuhIndonesia.text = dataIndonesia.sembuh
                tvMeninggalIndonesia.text = dataIndonesia.meninggal
                tvDirawatIndonesia.text = dataIndonesia.dirawat
            }

        })
    }

    private fun showMeninggalGlobal() {
        ApiService.instance.getGlobalMeninggal().enqueue(object : Callback<MeninggalGlobalModel>{
            override fun onFailure(call: Call<MeninggalGlobalModel>, t: Throwable) {
                toast("Gagal")
            }

            override fun onResponse(
                call: Call<MeninggalGlobalModel>,
                response: Response<MeninggalGlobalModel>
            ) {
                val responseMeninggal = response.body()!!
                tvMeninggalGlobal.text = responseMeninggal.valueMeninggalGlobal
            }

        })
    }

    private fun showSembuhGlobal() {
        ApiService.instance.getGlobalSembuh().enqueue(object : Callback<SembuhGlobalModel>{
            override fun onFailure(call: Call<SembuhGlobalModel>, t: Throwable) {
                toast("Gagal")
            }

            override fun onResponse(
                call: Call<SembuhGlobalModel>,
                response: Response<SembuhGlobalModel>
            ) {
                val responseSembuh = response.body()!!
                tvSembuhGlobal.text = responseSembuh.valueSembuhGlobal
            }

        })
    }

    private fun showPositifGlobal() {
        ApiService.instance.getGlobalPositif().enqueue(object : Callback<PositifGlobalModel>{
            override fun onFailure(call: Call<PositifGlobalModel>, t: Throwable) {
                toast("Gagal")
            }

            override fun onResponse(
                call: Call<PositifGlobalModel>,
                response: Response<PositifGlobalModel>
            ) {
                val responsePositif = response.body()!!
                tvPositifGlobal.text = responsePositif.valuePositifGlobal
            }

        })
    }
}