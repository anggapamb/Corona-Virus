package com.anggapambudi.coronavirus.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import com.anggapambudi.coronavirus.R
import com.anggapambudi.coronavirus.api.ApiService
import com.anggapambudi.coronavirus.model.DataIndonesiaModel
import kotlinx.android.synthetic.main.activity_splash_screen.*
import org.jetbrains.anko.longToast
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        //fullscreen
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        ApiService.instance.getDataIndonesia()
            .enqueue(object : Callback<ArrayList<DataIndonesiaModel>> {
                override fun onFailure(call: Call<ArrayList<DataIndonesiaModel>>, t: Throwable) {
                    longToast("Networking Error")
                }

                override fun onResponse(
                    call: Call<ArrayList<DataIndonesiaModel>>,
                    response: Response<ArrayList<DataIndonesiaModel>>
                ) {
                    val textIndonesia = response.body()!!
                    val indonesia = textIndonesia[0]
                    tvIndonesiaSplashScreen.text = indonesia.name

                    if (response.isSuccessful) {
                        Handler(Looper.getMainLooper()).postDelayed({
                            startActivity<MainActivity>()
                            finish()
                        }, 2000)
                    }
                }

            })


    }
}