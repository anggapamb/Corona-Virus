package com.anggapambudi.coronavirus.model

data class DataProvinsiModel(
    val attributes: ProvinsiModel
)