package com.anggapambudi.coronavirus.api

import com.anggapambudi.coronavirus.model.*
import retrofit2.Call
import retrofit2.http.GET

interface ApiEndPoint {

    @GET("positif/")
    fun getGlobalPositif(): Call<PositifGlobalModel>

    @GET("sembuh/")
    fun getGlobalSembuh(): Call<SembuhGlobalModel>

    @GET("meninggal/")
    fun getGlobalMeninggal(): Call<MeninggalGlobalModel>

    @GET("indonesia/")
    fun getDataIndonesia(): Call<ArrayList<DataIndonesiaModel>>

    @GET("indonesia/provinsi/")
    fun getDataProvinsi(): Call<ArrayList<DataProvinsiModel>>

}