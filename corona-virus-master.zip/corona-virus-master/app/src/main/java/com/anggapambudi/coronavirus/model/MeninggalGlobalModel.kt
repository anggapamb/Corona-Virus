package com.anggapambudi.coronavirus.model

import com.google.gson.annotations.SerializedName

data class MeninggalGlobalModel(
    @SerializedName("value")
    val valueMeninggalGlobal: String
)